const response = require("../../../network/response.js");
const express = require('express');
const { getConnection } = require('../../../model/db');


const router = express.Router();

router.get('/', function (req, res) {

    response.success(req, res, '', 200);
});

router.post('/login', function (req, res) {
    console.log(req.query);

    res.send({
        username: req.query.username,
        token: 'token',
        id_user: 'id_user',
        success: 'ok',
        metodo: 'login'
    });
});

router.post('/register', async function (req, res) {
    // Realiza la conexion a db
    const client = await getConnection();

    let username = req.query.username;
    let email = req.query.email;
    let password = req.query.password;
    let phone_number = req.query.phone_number;

    const query_request = {
        text: 'INSERT INTO tbl_usersdb(username, email, password, phone_number) VALUES ($1, $2, $3, $4)',
        values: [username, email, password, phone_number]
    }

    client.query(query_request)
        .then(r => { response.success(req, res, r, 200) })
        .catch(e => { response.success(req, res, e.detail, 200) });
});

module.exports = router;