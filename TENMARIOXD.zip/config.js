export const api = {
    port: process.env.API_PORT || 3000
};
export const db = {
    user: 'btguoyftpfoply',
    host: 'ec2-52-72-99-110.compute-1.amazonaws.com',
    database: 'dccllm8cq3jsfs',
    password: '49eda49a910e42fdb25cd3284ae7053c030d838d77bf3742ae467851aad48df0',
    port: '5432',
};  